

#include <iostream>
#include <string>
#include <unordered_map>
#include <cstdio>
#include <bitset>
#include <fstream>
using namespace std;
string refer(const string &b)
{//this function maps 4 digit binary to hexadecimal degits (ex; 1111 -> f) and returns the hexadecimal digit
    unordered_map<string, string> bmap = {{"0000", "0"}, {"0001", "1"}, {"0010", "2"}, {"0011", "3"}, {"0100", "4"}, {"0101", "5"}, {"0110", "6"}, {"0111", "7"}, {"1000", "8"}, {"1001", "9"}, {"1010", "a"}, {"1011", "b"}, {"1100", "c"}, {"1101", "d"}, {"1110", "e"}, {"1111", "f"}};
    return bmap[b];
}
string findfunc7(const string &func)
{//this function maps a function to its respective funct7 (ex; add -> 0000000) and returns funct7 binary
    unordered_map<string, string> funcmap = {{"add", "0000000"}, {"sub", "0100000"}, {"xor", "0000000"}, {"or", "0000000"}, {"and", "0000000"}, {"sll", "0000000"}, {"srl", "0000000"}, {"sra", "0100000"}, {"slt", "0000000"}, {"sltu", "0000000"}};
    return funcmap[func];
}
string findfunc3(const string &func)
{//this function maps a function to its respective funct3 (ex; add -> 000) and returns funct3 binary
    unordered_map<string, string> funcmap = {{"add", "000"}, {"addi", "000"}, {"sub", "000"}, {"xor", "100"}, {"xori", "100"}, {"or", "110"}, {"ori", "110"}, {"and", "111"}, {"andi", "111"}, {"sll", "001"}, {"slli", "001"}, {"srl", "101"}, {"srli", "101"}, {"sra", "101"}, {"srai", "101"}, {"slt", "010"}, {"slti", "010"}, {"sltiu", "011"}, {"ld", "011"}, {"lw", "010"}, {"lh", "001"}, {"lb", "000"}, {"lwu", "110"}, {"lhu", "101"}, {"lbu", "100"}, {"sd", "011"}, {"sw", "010"}, {"sh", "001"}, {"sb", "000"}, {"jalr", "000"}};
    return funcmap[func];
}
string findimm(const string &imm, const string &func)
{//this function converts immediate/offset values (string form) to 12 bit binary(string form) 
    int imm_num;
    try//error handling if the immediate/offset is not of integer form (ex; ab3g5)
    {
        imm_num = stoi(imm);
    }
    catch(const invalid_argument&)
    {
        return "0";
    }
    if(imm_num<-2048 || imm_num>2048)//error handling if immediate/offset is out of range
    {
        return "0";
    }
    

    if (imm_num < 0)//conversion in case of negative number
    {
        imm_num = (1 << 12) + imm_num;
    }
    bitset<12> binary(imm_num);
    string imm_bin = binary.to_string();
    if (func == "srai")
    {
        string func6 = "010000";//func6 in case of srai , slli , srli
        return func6 + imm_bin.substr(6, 6);
    }
    if (func == "srli" || func == "slli")
    {
        string func6 = "000000";
        return func6 + imm_bin.substr(6, 6);
    }
    else
    {
        return imm_bin;
    }
}
string findregbin(const string &reg)
{//this function returns the binary code for respective register in 5 bits
    if (reg == "x0" || reg == "zero")
    {
        return "00000";
    }
    else if (reg == "x1" || reg == "ra")
    {
        return "00001";
    }
    else if (reg == "x2" || reg == "sp")
    {
        return "00010";
    }
    else if (reg == "x3" || reg == "gp")
    {
        return "00011";
    }
    else if (reg == "x4" || reg == "tp")
    {
        return "00100";
    }
    else if (reg == "x5" || reg == "t0")
    {
        return "00101";
    }
    else if (reg == "x6" || reg == "t1")
    {
        return "00110";
    }
    else if (reg == "x7" || reg == "t2")
    {
        return "00111";
    }
    else if (reg == "x8" || reg == "s0" || reg == "fp")
    {
        return "01000";
    }
    else if (reg == "x9" || reg == "s1")
    {
        return "01001";
    }
    else if (reg == "x10" || reg == "a0")
    {
        return "01010";
    }
    else if (reg == "x11" || reg == "a1")
    {
        return "01011";
    }
    else if (reg == "x12" || reg == "a2")
    {
        return "01100";
    }
    else if (reg == "x13" || reg == "a3")
    {
        return "01101";
    }
    else if (reg == "x14" || reg == "a4")
    {
        return "01110";
    }
    else if (reg == "x15" || reg == "a5")
    {
        return "01111";
    }
    else if (reg == "x16" || reg == "a6")
    {
        return "10000";
    }
    else if (reg == "x17" || reg == "a7")
    {
        return "10001";
    }
    else if (reg == "x18" || reg == "s2")
    {
        return "10010";
    }
    else if (reg == "x19" || reg == "s3")
    {
        return "10011";
    }
    else if (reg == "x20" || reg == "s4")
    {
        return "10100";
    }
    else if (reg == "x21" || reg == "s5")
    {
        return "10101";
    }
    else if (reg == "x22" || reg == "s6")
    {
        return "10110";
    }
    else if (reg == "x23" || reg == "s7")
    {
        return "10111";
    }
    else if (reg == "x24" || reg == "s8")
    {
        return "11000";
    }
    else if (reg == "x25" || reg == "s9")
    {
        return "11001";
    }
    else if (reg == "x26" || reg == "s10")
    {
        return "11010";
    }
    else if (reg == "x27" || reg == "s11")
    {
        return "11011";
    }
    else if (reg == "x28" || reg == "t3")
    {
        return "11100";
    }
    else if (reg == "x29" || reg == "t4")
    {
        return "11101";
    }
    else if (reg == "x30" || reg == "t5")
    {
        return "11110";
    }
    else if (reg == "x31" || reg == "t6")
    {
        return "11111";
    }
    else//error handling in case of invalid register 
    {
        return "0";
    }
}
string hexconvert(const string &bin)
{//function takes the binary (32bit) of instruction and converts it into hexadecimal
    string convertedbin;
    for (int i = 0; i < 32; i += 4)//slices binary in string form by 4 digits and converts them 
    {
        convertedbin += refer(bin.substr(i, 4));
    }
    return convertedbin;//returns hexadecimal
}
string convertrtype(const string &func, const string &rd, const string &rs1, const string &rs2)
{//this function finds the binaries of registers , functions and returns hexadecimal (r type)
    string opcode = "0110011";
    string func7code = findfunc7(func);
    string func3code = findfunc3(func);
    string rdcode = findregbin(rd);
    string rs1code = findregbin(rs1);
    string rs2code = findregbin(rs2);
    if (func7code == "0" || func3code == "0" || rdcode == "0" || rs1code == "0" || rs2code == "0")
    {//error handling (0 is returned from other functions in case there is an error)
        return "0";
    }
    return hexconvert(func7code + rs2code + rs1code + func3code + rdcode + opcode);
    //the binaries are added in string form and sent to another function for conversion into hexadecimal and returns the value 
}
string convertitype(const string &func, const string &rd, const string &rs1, const string &imm)
{//this function finds the binaries of registers , functions , immediate value and returns hexadecimal(i type)
    string opcode;
    if (func == "ld" || func == "lw" || func == "lh" || func == "lb" || func == "lwu" || func == "lhu" || func == "lbu")
    {
        opcode = "0000011";//opcode for load 
    }
    else if (func == "jalr")
    {
        opcode = "1100111";//opcode for jalr
    }
    else
    {
        opcode = "0010011";
    }
    string func3code = findfunc3(func);
    string rdcode = findregbin(rd);
    string rs1code = findregbin(rs1);
    string immcode = findimm(imm, func);//function for finding binary of immediate value
    if (func3code == "0" || rdcode == "0" || rs1code == "0" || immcode == "0")
    {//error handling (0 is returned from other functions in case there is an error)
        return "0";
    }
    if(immcode == "0")
    {
        return "0";
    }
    return hexconvert(immcode + rs1code + func3code + rdcode + opcode);
}
string convertstype(const string &func, const string &rs1, const string &rs2, const string &imm)
{//this function finds the binaries of registers , functions , offset value and returns hexadecimal(s type)
    string opcode = "0100011";
    string func3code = findfunc3(func);
    string rs1code = findregbin(rs1);
    string rs2code = findregbin(rs2);
    string immcode = findimm(imm, func);//binary for offset
    if (func3code == "0" || rs1code == "0" || rs2code == "0" || immcode == "0")
    {
        return "0";
    }
    if(immcode == "0")
    {
        return "0";
    }
    return hexconvert(immcode.substr(0, 7) + rs1code + rs2code + func3code + immcode.substr(7, 5) + opcode);
}
string separator(string s)//this function operates on slicing strings 
{
    int spc = s.find(' ');
    string func = s.substr(0, spc);//function present in the instruction is contained in func
    string remaining = s.substr(spc + 1);//the remaining part of instruction is stored in "remaining"
    if (func == "add" || func == "sub" || func == "and" || func == "or" || func == "xor" || func == "sll" || func == "srl" || func == "sra")
    {//this block of code separates the registers
        int comma1 = remaining.find(',');
        string rd = remaining.substr(0, comma1);
        int comma2 = remaining.find(',', comma1 + 1);
        string rs1 = remaining.substr(comma1 + 2, comma2 - comma1 - 2);
        string rs2 = remaining.substr(comma2 + 2);
        if(comma1 < 0 || comma2 < 0)//error handling if less arguments are given
        {
            return "0";
        }
        string hex = convertrtype(func, rd, rs1, rs2);//separated parts of instructions (ex; "add","x1",...) are sent to another function
        return hex;
    }
    else if (func == "addi" || func == "andi" || func == "ori" || func == "xori" || func == "slli" || func == "srli" || func == "srai")
    {//this block of code separates registers and immediate values
        int comma1 = remaining.find(',');
        string rd = remaining.substr(0, comma1);
        int comma2 = remaining.find(',', comma1 + 1);
        string rs1 = remaining.substr(comma1 + 2, comma2 - comma1 - 2);
        string imm = remaining.substr(comma2 + 2);
        if(comma1 < 0 || comma2 < 0)//error handling if less arguments are given
        {
            return "0";
        }
        string hex = convertitype(func, rd, rs1, imm);
        return hex;
    }
    else if (func == "ld" || func == "lw" || func == "lh" || func == "lb" || func == "lwu" || func == "lhu" || func == "lbu" || func == "jalr")
    {//this block of code separates registers and offsets 
        int comma1 = remaining.find(',');
        string rd = remaining.substr(0, comma1);
        int br1 = remaining.find('(');
        string imm = remaining.substr(comma1 + 2, br1 - comma1 - 2);
        int br2 = remaining.find(')');
        string rs1 = remaining.substr(br1 + 1, br2 - br1 - 1);
        if(br1 < 0 || br2 < 0)//error handling
        {
            return "0";
        }
        string hex = convertitype(func, rd, rs1, imm);
        return hex;
    }
    else if (func == "sd" || func == "sw" || func == "sh" || func == "sb")
    {//this block of code separates registers and offsets 
        int comma1 = remaining.find(',');
        string rs1 = remaining.substr(0, comma1);
        int br1 = remaining.find('(');
        string imm = remaining.substr(comma1 + 2, br1 - comma1 - 2);
        int br2 = remaining.find(')');
        string rs2 = remaining.substr(br1 + 1, br2 - br1 - 1);
        if(br1 < 0 || br2 < 0)
        {
            return "0";
        }
        string hex = convertstype(func, rs1, rs2, imm);
        return hex;
    }
    else//error handling in case the function in the instruction is not found
    {
        return "0";
    }
    return 0;
}
int main()
{
    ifstream ifile{"input.s"}; //opening input file
    ofstream ofile{"output.hex"};//opening output file
    string s = ""; 
    int line = 1; //line index
    while (getline(ifile, s)) // s takes each line of input file
    {
        if (s == "") //terminating
        {
            break;
        }
        string hexcode = separator(s); 
        if (hexcode == "0") // errors handled 
        {
            cout<<"error in line "<<line<<endl; //line number in which error is present is given as output in console
            ofile << "error" << endl;//error is updated to output file
        }
        else
        {
            ofile << hexcode << endl;//output updated
        }
        line = line + 1; //iterating line
    }
    return 0;
}
