CXX = g++

OBJECTS = assembler.cpp
all: riscv_asm
riscv_asm: $(OBJS)
	$(CXX)  $(OBJECTS) -o riscv_asm

clean:
	rm -f $(OBJS) riscv_asm